package com.pwszit.singiel;

public class Constant {
    public static final String URL = "http://192.168.240.249/";
    public static final String HOME = URL+"api";
    public static final String LOGIN = HOME+"/auth/login";
    public static final String REGISTER = HOME+"/auth/register";
}
